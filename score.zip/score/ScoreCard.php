<?php
$db = new mysqli("localhost","root","1$=46.10RupeesSQL","gate");
$rs = $db->query("select *from ScoreCard where regstno='GG16S21017020'");
while($row = $rs->fetch_array())
{
	$regno = trim($row['regstno']);
	$qr = trim($row['QRCode']);
	$papercode = trim($row['papercode']);
	$papername = trim($row['papername']);
	$sec1 = trim($row['sec1']);
	$sec1name = trim($row['sec1name']);
	$sec2 = trim($row['sec2']);
	$sec2name = trim($row['sec2name']);
	$name = trim($row['name']);
	$rmark = trim($row['rawmarks']);
	$omark = trim($row['normarks']);
	$score = trim($row['scroe']);
	$air = trim($row['air']);
	$cat = trim($row['category']);
	$pwd = trim($row['pwd']);
	$gender = trim($row['gender']);
	$finger = trim($row['finger']);
	$photo = trim($row['photopath']);
	$sign = trim($row['signpath']);
	$gen = trim($row['gencutoff']);
	$obc = trim($row['obccutoff']);
	$scst = trim($row['sccutoff']);
}
$rs = $db->query("select total_can from candidate where papercode='$papercode'");
$row = $rs->fetch_row();
$total = $row[0];
mysqli_close($db);

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>GATE 2016</title>
<style type="text/css" media="print">
	#jp{display:none}
	#hd{display:none}
</style>
<link type="text/css" href="mystyle.css" media="all" rel="stylesheet"/>
</head>
<body> 
 	 <center>

			  
 
<table border="1" bordercolor="#000000" style="border-collapse:collapse" cellpadding="5px" cellspacing="0" width="650" height="413">
		<tr>
			<td colspan="4">
				<table width="100%" border="0" bordercolor="#000000" style="border-collapse:collapse">
				<tr>
					<td width="487"   align="left" valign="top" class="rgt"> 
					 <table border="0" bordercolor="#000000" cellpadding="0" cellspacing="0" style="border-collapse:collapse" width="100%">
					   <tr>
					     <td >
						    <img src="img/iisclogo.png" width="80" height="80"/>					     </td>
						 <td valign="top">
						 	<table width="100%" style="border-collapse:collapse" cellpadding="0" cellspacing="0">
								<tr height="30">
									<td colspan="2" align="center">
										 <font face="arial" size="5"><b>GATE 2016 Scorecard</b></font>								</td>
								</tr>
								<tr height="25">
									<td width="100%" align="center">
										 <font face="arial" size="3"><b>Graduate Aptitude Test in Engineering</b></font>								</td>
								    <td width="17%" align="right">
																		</td>
								</tr>
								<tr height="25">
									<td colspan="2" align="center">
										<font face="arial" size="2">
										<b>
																				</b>										</font>							</td>
								</tr>
							</table>
						
						 </td>
					   </tr>
						 
						
				 </table>								
					
						 
				  </td>	 					
					<td width="151"  colspan="2" align="left"  valign="top">
						<table style="border-collapse:collapse" align="left" cellpadding="0" cellspacing="">
						<tr height="5px;"><td></td><td></td></tr>
						<tr height="10">
						 <td width="68"   align="left">
								<font size="1.5" face="arial">
								  REG.No:				</font>			</td>    	            
						  <td width="82"  align="left">
							<font size="1.5" face="arial">
							<b>
						    <?php echo $regno; ?>							</b>							</font>			</td>            
					  </tr>
					  <tr height="5px;"><td></td><td></td></tr>
						 <tr  height="10" align="left">
						   <td>  
							 <font size="1.5" face="arial">
									 QR Code.:				</font>		</td>
							 <td  align="left">
								<font size="1.5" face="arial">
									 <b><?php echo $qr; ?>	</b>		</font>			</td>         
						  </tr>
					  <tr height="25">
					    <td colspan="2" align="center">
						<font size="1" face="tahoma">
						<b>
							  
							LEGAL COPY	
					    </b>
						  </font>
						</td>
					    </tr>
						 
						
				  </table>				  </td>
				</tr>	
				</table>			</td>
		</tr>
    
	    <tr>
		  <td>
		    <table width="648" border="0" bordercolor="#000000" style="border-collapse:collapse" cellpadding="0" cellspacing="0">
		  	<tr>
		    	<td width="138"  height="19"  align='left' valign="middle">
				&nbsp; <font size="1" face="arial"></font></td>
	        	<td width="346" height="19" align='left' class="rgt" valign="middle">
				 <font size="1" face="tahoma">
				<b></b>				</font></td>
				
				<td width="164"  colspan="1" rowspan="5" align="center">
					<img src='img/modi.jpg' width='70' height='80'>&nbsp	
			   </td>                         
		</tr>
		    <tr>
		      <td height="19"  align='left' valign="top">&nbsp; <font size="2" face="arial">Name<span style="margin-right: 10px; float: right;">:</span></font></td>
		      <td height="19"  align='left' class="rgt" valign="top"><font size="2" face="arial"><b><?php echo strtoupper($name); ?></b> </font></td>
		      </tr>
		    <tr>
		     <td height="19"  align='left' valign="top">&nbsp; <font size="2" face="arial"> Gender <span style="margin-right: 10px; float: right;">:</span> </font> </td>
		    <td height="19"  align='left' class="rgt" valign="top"><font size="2" face="arial"><?php echo strtoupper($gender); ?> </font> </td>
	    </tr>
		  <tr>
		     <td height="19"  align='left' valign="top">&nbsp; <font size="2" face="arial"> Paper Code<span style="margin-right: 10px; float: right;">:</span> </font> </td>
		    <td height="19"  align='left' class="rgt" valign="top">  <font size="2" face="arial"> <?php echo $papercode; ?> </font> </td>
	    </tr>
		  
		  <tr>
		    <td height="19"  align='left' valign="top">&nbsp; <font size="2" face="arial"> Paper Name<span style="margin-right: 10px; float: right;">:</span></font> </td>
		    <td height="19"  align='left' class="rgt" valign="top"><font size="2" face="arial"> <?php echo strtoupper($papername); ?> </font> </td>
      </tr>
		  <tr height="20">
		    <td height="19"  align='left' valign="top">&nbsp;
			  <font size="2" face="arial">
			  Category <span style="margin-right: 10px; float: right;">:</span>		  </font>		  </td>
			  <td  align='left' class="rgt" height="19" valign="top">
			  <font size="2" face="tahoma">
					<?php echo $cat; ?>	
			  </font>			 
				
&nbsp; 			</td>
			<td colspan="1" rowspan="3" align="center"  height="50" width="164" class="top">
				<img src='img/sign.png' width='120' height='40'>&nbsp		  </td>
	  </tr>
		  <tr height="20">
		    <td height="19"  align='left' valign="top">&nbsp;
			 <font size="2" face="arial">
			  		 </font>			</td>
		    <td  align='left' class="rgt" height="20" valign="top">

			 <font size="2" face="arial">
						
			  </font>			</td>
		    </tr>
	  </table>
	  </td>
	  </tr>
		<tr>
			<td colspan="2" align="center" height="2px">
				
			</td>
            
		</tr>
					<tr height="35">
			  <td height="1" colspan="4" valign="top" align="left">
				 	
					  
				<div style=" background-image: url(gw.png); background-size: cover; width: 100%; min-height: 150px; height: auto; font-family: arial; font-size: 14px;">
					<table border="0" cellpadding="3" width="100%" style="border-collapse: separate; border-spacing: 0 1em;">
						<tr>
							<td width="25%">GATE Score</td>
							<td width="25%" style="font: normal 16px arial; text-align:center; border: 1px solid black;"><b><?php echo $score; ?></b></td>
							<td width="3%"></td>
							<td width="47%"><table border="0" width="100%"><tr>
													<td width="70%">All India Rank in this paper.</td>
													<td width="30%" style="padding: 3px; text-align:center; border: 1px solid black;"><b><?php echo $air; ?></b></td>
												</tr>
											</table></td>
						</tr>
						<tr>
							<td width="25%">Marks out of 100*</td>
							<td width="25%" style="text-align:center; border: 1px solid black;"><b><?php echo $rmark; ?></b></td>
							<td width="3%"></td>
							<td width="47%"><table width="100%">
												<tr>
													<td width="70%">No. of Candidate Appeared in this paper.</td>
													<td width="30%" style="padding: 5px; text-align:center; border: 1px solid black;"><b><?php echo $total; ?></b></td>
												</tr></table>
												</td>
						</tr>
						<tr>
							<td width="25%">Qualifying Marks**</td>
							<td width="25%">
								<table width="100%">
								<tr>
									<td style="text-align: center; border: 1px solid black;"><?php echo $gen; ?></td>
									<td style="text-align: center; border: 1px solid black;"><?php echo $obc; ?></td>
									<td style="text-align: center; border: 1px solid black;"><?php echo $scst; ?></td>
								</tr>
								<tr>
									<td style="font-size: 10px;">GENERAL</td>
									<td style="font-size: 10px;">OBC(NCL)</td>
									<td style="font-size: 10px;">SC/ST/PWD</td>
								</tr>
								</table>
							</td>
							<td width="3%"></td>
							<td width="47%" style="text-align: center;">
								<span style="font-size: 12px;"><b>Valid from March 22, 2016 to March 22, 2018</b></span>
							</td>
						</tr>
					</table>
				</div>	 
				
				 </td>
		</tr>
		<tr>
			<td height="55" colspan="4" align="center" valign="bottom">
			
		  <div align="left" style="margin-left: 10px; padding: 5px;">
		  <font size="1" face="arial">
			  <b>
				NOTE:
			  </b>
		    </font>
		    <p style="font-size: 10px;">
		    	* Normalized marks for multisession papers (CE,CS,EC,EE,ME)<br>
		    	** A candidate is considered qualified if the marks secured are greater than or equal to the qualifying marks mentioned for the category for which a valid category cerrificate, if applicable, is produced along with this scorecard.
		    </p>
		  </div>
		 

		  <table height="60px" width="100%" style="border-collapse:collapse" border="0" cellpadding="5" cellspacing="0">
			  <tr>
				<td width="31%" align="center" valign="bottom">
					 <font size="1" face="arial">
							  </font>				</td>
				<td width="41%" align="center" valign="bottom">
				<font size="1" face="arial">&nbsp;
				  				</font>						</td>
				<td width="28%" align="center" valign="bottom">
					<font size="2" face="arial, Arial, Helvetica, sans-serif">&nbsp;
					<B>Tirthankar Bhattacharyya</B>
					</font>
					<br />
					  <font size="1" face="arial">
						Chairman, GATE 2016	<br>				  </font>			    </td>
		    </tr>
		  </table>	
		  
		  </td>
		</tr>	
</table>
</center>
</body>
</html>
 
 
 
