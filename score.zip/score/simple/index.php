<!DOCTYPE html>
<html>
<head>
	<title>GATE 2016 - IISc</title>
</head>
<body>
<form action="getScoreCard.php" method="post">
	<input type="text" name="qrcode" placeholder="QR Code Here">
	<img src="captcha.php" />
	<input type="text" name="captcha" placeholder="Captcha Here" />
	<input type="submit" value="Submit">
</form>
</body>
</html>