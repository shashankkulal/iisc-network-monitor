<?php
/*
	$qrcode = $_POST['qrcode'];
	$captcha = $_POST['captcha'];
	session_start();
	if($captcha != $_SESSION['digit'])
	{
		session_destroy();
		header("location:index.php");
	}
	session_destroy();

	if(empty($qrcode))
	{
		header("location:index.php");
	}
	*/

$file = fopen("my.csv","r");
print_r(fgetcsv($file));
fclose($file);
?>