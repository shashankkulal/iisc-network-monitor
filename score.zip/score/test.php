<?php
function getTotalCandidate($papercode)
{
	
	$db = new mysqli("localhost","root","1$=46.10RupeesSQL","gate");
	$rs = $db->query("select *from candidate where papercode='$papercode'");
	$row = $rs->fetch_row();
	$total = $row[1];
	print $total;
	mysqli_close($db);
}

$papercode = "GG";
getTotalCandidate($papercode);
?>