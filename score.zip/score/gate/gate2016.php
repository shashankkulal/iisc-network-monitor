<!DOCTYPE html>
<html>
<head>
	<title>GATE 2016</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
</head>
<body>
<nav class="navbar navbar-inverse navbar-static-top">
<div class="container">
	<a class="navbar-brand" href="#">Indian Institute of Science</a>
</div>
</nav>

<div class="page-header">
	<img src="gatebanner.png" />
</div>

<div class="container">
  <div class="row">
    <div class="col-lg-1" style="margin: 0 auto;">hello</div>
  </div>
</div>


<script   src="https://code.jquery.com/jquery-2.2.2.min.js"   integrity="sha256-36cp2Co+/62rEAAYHLmRCPIych47CvdM+uTBJwSzWjI="   crossorigin="anonymous"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>