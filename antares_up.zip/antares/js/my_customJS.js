$(document).ready(function(){
    $("#leftbar_toggle").click(function(){
        $("#leftbar").toggle();
    });
});