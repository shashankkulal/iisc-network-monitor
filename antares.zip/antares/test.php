<?php 
echo basename($_SERVER['PHP_SELF']);
?>