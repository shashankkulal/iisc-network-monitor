 <html>
<head><title>Testing</title>
<script src='https://www.google.com/recaptcha/api.js'></script>
</head>
    <body>
      <form method="post" action="form.php">
	<div class="g-recaptcha" data-sitekey="6LenpBkTAAAAAABGTD1K7ZTKgh_lc1fwcVucK5Qz"></div>
        <input type="submit" />
      </form>
    </body>
  </html>
