import os

os.system("python speedtest_cli.py > test.txt")
