#!/usr/bin/env python
import os
os.system("ping -c 1 10.114.1.1 > demo.txt")
