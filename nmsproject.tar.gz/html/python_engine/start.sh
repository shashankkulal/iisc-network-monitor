#!/bin/sh
cd /var/www/html/python_engine
./start.py
echo "All done. Exiting bash scrpt"
