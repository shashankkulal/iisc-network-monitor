<?php

require dirname(dirname(__FILE__)).'/lang/en.php';
