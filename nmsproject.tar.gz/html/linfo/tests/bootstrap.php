<?php

define('LINFO_TESTING', 1);
define('LINFO_TESTDIR', dirname(__FILE__));

require_once dirname(dirname(__FILE__)).'/init.php';

