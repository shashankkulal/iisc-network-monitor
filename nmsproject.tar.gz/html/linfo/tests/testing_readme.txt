Unit test instructions:

This assumes you have phpunit installed somewhere in your $PATH. I just save
the phpunit.phar file to ~/bin/phpunit

For writing new tests, use two space indent. The rest of Linfo should be two
space indent but for legacy reasons it remains tabs.
