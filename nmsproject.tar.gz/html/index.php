<?php
	if(!isset($_GET['id']))
	{
		header("location:login.php");
	}
?>
<center>
<h1>Work is on Progress</h1><br>
<img src="http://4.bp.blogspot.com/-Xsbd1jB28S0/VMuL2jwhUWI/AAAAAAAAEDc/kaFm7dhh6vo/s1600/work%2Bin%2Bprogress.png" /><br><br>
<h3>Login from <a href="login.php">here</a></h3>

</center>
