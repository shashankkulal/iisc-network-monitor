<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li>
                <a href="home.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboard</span> </a>
            </li>
            <li>
                <a href="hoststatus.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Hosts</span> </a>
            </li>
            <li>
                <a href="link_status.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Link Status</span> </a>
            </li>
            <li>
                <a href="linfo/" target="_blank" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">My Status</span> </a>
            </li>
            <li>
                <a href="internet_speed.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Internet Speed</span> </a>
            </li>
            <li>
                <a href="settings.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Settings</span> </a>
            </li>
        </ul>
    </div>
</div>
