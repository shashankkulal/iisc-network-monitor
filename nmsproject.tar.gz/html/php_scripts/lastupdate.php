<?php
$u = $_GET['u'];
echo time()-$u;
?>
