<?php
    $s = $_POST['server'];
    echo $s;
?>