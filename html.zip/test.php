<?php
function getpacketloss() {
    $command = 'wget -O /dev/null http://speedtest.wdc01.softlayer.com/downloads/test10.zip -o bandwidth.log';
    shell_exec($command);
    $file = shell_exec('tail -1 bandwidth.log');
    #preg_match_all('/\((.*?)\)/', $file, $matches);
    #print_r($matches);
    print_r($file);
}
#getpacketloss();
echo shell_exec('python python_engine/test.py');

?>